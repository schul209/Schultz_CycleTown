﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TB_QuestGame
{
    /// <summary>
    /// class to store static and to generate dynamic text for the message and input boxes
    /// </summary>
    public static class Text
    {
        public static List<string> HeaderText = new List<string>() { "Race to Cherry Town" };
        public static List<string> FooterText = new List<string>() { "Thresa Schultz, 2017" };

        #region INTITIAL GAME SETUP

        public static string JourneyIntro()
        {
            string messageBoxText =
            "Oh no! Your car will not start and you need to meet " +
            "your friends at the fesitval at 4:00pm, " +
            "This leaves you 40 minutes to get there. " +
            "Pack what you need on your bike and get going! " +
            "I hope your tires are aired up and you have enough energy to get there. \n" +
            " \n" +
            "Press the Esc key to exit the game at any point.\n" +
            " \n" +
            "Your journey begins now.\n" +
            " \n" +
            "\tYour first task will be to set up the initial parameters of your journey.\n" +
            " \n" +
            "\tPress any key to begin the Process.\n";

            return messageBoxText;
        }

        public static string CurrentLocationInfo(CityLocation cityLocation)
        {
            string messageBoxText =
            $"Current Location: {cityLocation.CommonName}\n" +
            "\n" +
            cityLocation.Description;
             
            return messageBoxText;
        }
        #endregion

        #region Initialize Journey Text

        public static string InitializeJourneyIntro()
        {
            string messageBoxText =
                "Before you begin your journey enter your trip information.\n" +
                " \n" +
                "Please enter your information below when prompted.\n" +
                " \n" +
                "\tPress any key to begin.";

            return messageBoxText;
        }

        public static string InitializeJourneyGetCyclistName()
        {
            string messageBoxText =
                "Please enter your name below.";

            return messageBoxText;
        }
        public static string InitializeGetCyclistNickname(Cyclist gameCyclist)
        {
            string messageBoxText =
                $"Do you have a nickname {gameCyclist.Name}?\n" +
                 "Please use the name you wish to be referred during your journey.";


            return messageBoxText;
        }
        

        public static string InitializeJourneyGetCyclistFitnessLevel(Cyclist gameCyclist)
        {
            string messageBoxText =
                $"Very good then, we will call you {gameCyclist.nickname} on your journey.\n" +
                " \n" +
                "Enter your fitness level on a scale of 1-10 below.\n" +
                " \n" +
                "Please enter a number between 1 and 10.";

            return messageBoxText;
        }

        public static string InitializeJourneyGetCyclistItem(Cyclist gameCyclist)
        {
            string messageBoxText =
                $"{gameCyclist.nickname}, Please tell what item may already be in your bag.\n" +
                " \n" +
                "Enter your current item in the bag below.\n" +
                " \n" +
                "Please choose from the options given below." +
                " \n";

            string itemList = null;

            foreach (Character.ItemType item in Enum.GetValues(typeof(Character.ItemType)))
            {
                if (item != Character.ItemType.None)
                {
                    itemList += $"\t{item}\n";
                }
            }

            messageBoxText += itemList;

            return messageBoxText;
        }
        public static string InitializeJourneyGetCyclistAiredTires(Cyclist gameCyclist)
        {
            string messageBoxText =
                $"{gameCyclist.nickname}, Do your bike tires have air?\n" +
                "\n" +
                "Please enter true or false below" +
                "\n";

                return messageBoxText;
        }
        public static string InitializeJourneyGetCyclistAge(Cyclist gameCyclist)
        {
            string messageBoxText =
                $"Alright {gameCyclist.nickname}, what is your age?\n" +
                " \n" +
                "Please enter your age below.";

            return messageBoxText;
        }
        public static string InitializeJourneyGetCyclistIsFast(Cyclist gameCyclist)
        {
            string messageBoxText = 
                $"{gameCyclist.nickname}, are you a fast cyclist?\n" +
                "\n" +
                "Or do you like to take your time?\n" +
                "\n" +
                "Please enter true if you are fast, false if not below.";
            return messageBoxText;
        }
        public static string InitializeJourneyGetCyclistBike(Cyclist gameCyclist)
        {
            string messageBoxText =
                $"{gameCyclist.nickname}, What type of bike are you riding?\n" +
                " \n" +
                "Enter your bicycle type.\n" +
                " \n" +
                "Please choose from the options given below." +
                " \n";

            string bikeList = null;

            foreach (Character.BikeType bike in Enum.GetValues(typeof(Character.BikeType)))
            {
                if (bike != Character.BikeType.None)
                {
                    bikeList += $"\t{bike}\n";
                }
            }

            messageBoxText += bikeList;

            return messageBoxText;
        }
       
        public static string InitializeJourneyEchoCyclistInfo(Cyclist gameCyclist)
        {
            string messageBoxText =
                $"Very good then {gameCyclist.nickname}.\n" +
                " \n" +
                "We have gathered the information to start your journey. You will find it" +
                " listed below.\n" +
                " \n" +
                $"\tCyclist Name: {gameCyclist.Name}\n" +
                $"\tCyclist Fitness Level: {gameCyclist.FitnessLevel}\n" +
                $"\tCyclist Bag Item: {gameCyclist.Item}\n" +
                $"\tCyclist Aired Tires: {gameCyclist.AiredTires}\n" +
                $"\tCyclist Age: {gameCyclist.Age}\n" +
                $"\tCyclist Is Fast: {gameCyclist.IsFast}\n" +
                $"\tCyclist Type of Bike: {gameCyclist.Bike}\n" +
                " \n" +
                "Press any key to begin your journey.";

            return messageBoxText;
        }
        

        

        #endregion

        #region MAIN MENU ACTION SCREENS

        public static string CyclistInfo(Cyclist gameCyclist)
        {
            string messageBoxText =
                $"\tCyclist Name: {gameCyclist.Name}\n" +
                $"\tCyclist Fitness Level: {gameCyclist.FitnessLevel}\n" +
                $"\tCyclist Bag Item: {gameCyclist.Item}\n" +
                $"\tCyclist Aired Tires: {gameCyclist.AiredTires}\n" +
                $"\tCyclist Age: {gameCyclist.Age}\n" +
                $"\tCyclist Is Fast: {gameCyclist.IsFast}\n" +
                $"\tCyclist Type of Bike: {gameCyclist.Bike}\n" +
                " \n";

            return messageBoxText;
        }
        public static string CyclistExitScreen(Cyclist gameCyclist)
        {
            string messageBoxText =
            $"\t{gameCyclist.nickname} You are a quiter!/\n" +
               "\tYou did not meet your friends\n" +
                "\tCome back and play again.\n" +
                "\n" +
                "\tPress enter to continue.";
                
            return messageBoxText;

        }
        public static string LookAround(CityLocation cityLocation)
        {
            string messageBoxText =
                $"Current Location: {cityLocation.CommonName}\n" +
                "\n" +
                cityLocation.GeneralContents;

            return messageBoxText;

        }
        public static string LookAt(GameObject gameObject)
        {
            string messageBoxText = "";

            messageBoxText =
                $"{gameObject.Name}\n" +
                "\n" +
                gameObject.Description + "\n" +
                "\n";
            if (gameObject is CyclistObject)
            {
                CyclistObject cyclistobject = gameObject as CyclistObject;

                messageBoxText += $"The {cyclistobject.Name} effects your time by {cyclistobject.TravelMinutes} and ";
                
                if (cyclistobject.CanInventory)
                {
                    messageBoxText += "may be added to your inventory.";
                }
                else
                {
                    messageBoxText += "May not be added to your inventory.";
                }
            }
            else
            {
                messageBoxText += $"The {gameObject.Name} may not be added to your inventory.";
            }
            return messageBoxText; 
        }
        public static string CurrentInventory(IEnumerable<CyclistObject> inventory)
        {
            string messageBoxText = "";

            //
            // display table header
            //
            messageBoxText =
            "ID".PadRight(10) +
            "Name".PadRight(30) +
            "Type".PadRight(10) +
            "\n" +
            "---".PadRight(10) +
            "----------------------------".PadRight(30) +
            "----------------------".PadRight(10) +
            "\n";

            //
            // display all cyclist objects in rows
            //
            string inventoryObjectRows = null;
            foreach (CyclistObject inventoryObject in inventory)
            {
                inventoryObjectRows +=
                    $"{inventoryObject.Id}".PadRight(10) +
                    $"{inventoryObject.Name}".PadRight(30) +
                    $"{inventoryObject.Type}".PadRight(10) +
                    Environment.NewLine;
            }

            messageBoxText += inventoryObjectRows;

            return messageBoxText;
        }
        public static string DisplayListCityLocations(List<CityLocation> CityLocations)
        {
            string messageBoxText =
                "City Location\n" +
                "\n" +

                //
                //display table header
                //
                "ID".PadRight(10) + "Name".PadRight(30) + "\n" +
                "---".PadRight(10) + "------------------------".PadRight(30) + "\n";

            //
            //Display all locations
            //
            string cityLocationList = null;
            foreach (CityLocation cityLocation in CityLocations)
            {
                cityLocationList +=
                    $"{cityLocation.CityLocationID}".PadRight(10) +
                    $"{cityLocation.CommonName}".PadRight(30) +
                    Environment.NewLine;
            }
            messageBoxText += cityLocationList;

            return messageBoxText;
        }
        public static string ListAllGameObjects(IEnumerable<GameObject> gameObjects)
        {
            //
            // display table name and column headers
            //
            string messageBoxText =
                "Game Objects\n" +
                " \n" +

                //
                // display table header
                //
                "ID".PadRight(10) +
                "Name".PadRight(30) +
                "Space-Time Location Id".PadRight(10) + "\n" +
                "---".PadRight(10) +
                "----------------------".PadRight(30) +
                "----------------------".PadRight(10) + "\n";

            //
            // display all cyclist objects in rows
            //
            string gameObjectRows = null;
            foreach (GameObject gameObject in gameObjects)
            {
                    gameObjectRows +=
                    $"{gameObject.Id}".PadRight(10) +
                    $"{gameObject.Name}".PadRight(30) +
                    $"{gameObject.CityLocationId}".PadRight(10) +
                    Environment.NewLine;
            }

            messageBoxText += gameObjectRows;

            return messageBoxText;
        }
        
        public static string GameObjectsChooseList(IEnumerable<GameObject> gameObjects)
            {
            //
            //table and column headers
            //
            string messageBoxText =
            "Game Objects \n" +
            "\n" +

                //
                // display header
                //
                "ID".PadRight(10) +
                "Name".PadRight(30) + "\n" +
                "---".PadRight(10) +
                "--------".PadRight(30) + "\n";

            //
            //display cyclist objects in rows
            //
            string gameObjectRows = null;
            foreach (GameObject gameObject in gameObjects)
            {
                gameObjectRows +=
                    $"{gameObject.Id}".PadRight(10) +
                    $"{gameObject.Name}".PadRight(30) +
                    Environment.NewLine;

            }
            messageBoxText += gameObjectRows;
            return messageBoxText; 

            }
        public static string Travel (Cyclist gameCyclist, List<CityLocation> cityLocations)
        {
            string messageBoxText =
                $"{gameCyclist.nickname}, Where would you wish to go? \n" +
                "\n" +
                //
                //display table header
                //
                "ID".PadRight(10) + "Name".PadRight(30) + "Accessible".PadRight(10) + "\n" +
                 "---".PadRight(10) + "-----------------".PadRight(30) + "-------".PadRight(10) + "\n";
            //
            //Display all locations except for current location
            //
            string cityLocationList = null; 
            foreach (CityLocation cityLocation in cityLocations)
            {
                if (cityLocation.CityLocationID != gameCyclist.CityLocationId)
                {
                    cityLocationList +=
                        $"{cityLocation.CityLocationID}".PadRight(10) +
                        $"{cityLocation.CommonName}".PadRight(30) +
                        $"{cityLocation.Accessable}".PadRight(10) +
                        Environment.NewLine;
                }
            }
            messageBoxText += cityLocationList;

            return messageBoxText;
        }
        public static string VisitedLocations(List<CityLocation> cityLocations)
        {
            string messageBoxText =
                "City Locations visited\n" +
                "\n" +

                //
                //display table header
                //
                "ID".PadRight(10) + "Name".PadRight(30) + "\n" +
                "---".PadRight(10) + "------------------------".PadRight(30) + "\n";

            //
            //Display all locations
            //
            string cityLocationList = null;
            foreach (CityLocation cityLocation in cityLocations)
            {
                cityLocationList +=
                    $"{cityLocation.CityLocationID}".PadRight(10) +
                    $"{cityLocation.CommonName}".PadRight(30) +
                    Environment.NewLine;
            }
            messageBoxText += cityLocationList;

            return messageBoxText;
        }
        #region Status
        public static List<string> StatusBox(Cyclist cyclist, City city)
        {
            List<string> statusBoxText = new List<string>();

            statusBoxText.Add($"Total Minutes: {cyclist.TotalMinutes} \n");
            statusBoxText.Add($"Hydration: {cyclist.Hydration} \n");
            statusBoxText.Add($"Speed: {cyclist.Speed} \n");

            return statusBoxText; 
        }


        #endregion


        #endregion
    }
}
