﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TB_QuestGame
{
    /// <summary>
    /// base class for the player and all game characters
    /// </summary>
    public class Character
    {
        #region ENUMERABLES

        public enum ItemType
        {
            None,
            airPump,
            water,
            cherries,
            CherryTokens 
            

        }

        public enum BikeType
        {
            None, 
            Road,
            Mountain, 
            BMX, 
            Tricycle

        }

        #endregion

        #region FIELDS

        private string _name;
        private int _fitnessLevel;
        private ItemType _item;
        private bool _airedTires;
        private int _age;
        private bool _isFast;
        private BikeType _bike;
        private string _nickname;
        protected int _cityLocationId;

        

        #endregion

        #region PROPERTIES

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public int FitnessLevel
        {
            get { return _fitnessLevel; }
            set { _fitnessLevel = value; }
        }

        public ItemType Item 
        {
            get { return _item; }
            set { _item = value; }
        }
        public bool AiredTires
        {
            get { return _airedTires; }
            set { _airedTires = value; }
        }
        public int Age
        {
            get { return _age; }
            set { _age = value; }
        }
        public bool IsFast
        {
            get { return _isFast; }
            set { _isFast = value; }
        }
        public BikeType Bike
        {
            get { return _bike; }
            set { _bike = value; }
        }
        public string nickname
        {
            get { return _nickname; }
            set { _nickname = value; }
        }
        public int CityLocationId
        {
            get { return _cityLocationId; }
            set { _cityLocationId = value; }
        }



        #endregion

        #region CONSTRUCTORS

        public Character()
        {

        }

        public Character(string name, ItemType item, int cityLocationID)
        {
            _name = name;
            _item = item;
            _cityLocationId = cityLocationID;

        }

        #endregion

        #region METHODS



        #endregion
    }
}
