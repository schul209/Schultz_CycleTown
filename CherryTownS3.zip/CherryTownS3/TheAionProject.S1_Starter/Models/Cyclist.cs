﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TB_QuestGame
{
    /// <summary>
    /// the character class the player uses in the game
    /// </summary>
    public class Cyclist : Character
    {
        #region ENUMERABLES


        #endregion

        #region FIELDS
        private List<int> _cityLocationsVisited;
        private int _totalMinutes;
        private bool _hydration;
        private int _speed;
        private List<CyclistObject> _inventory;

        


        #endregion

        #region PROPERTIES
        public List<int> CityLocationsVisited
        {
            get { return _cityLocationsVisited; }
            set { _cityLocationsVisited = value; }
        }
        public int TotalMinutes
        {
            get { return _totalMinutes; }
            set { _totalMinutes = value; }
        }
        public bool Hydration
        {
            get { return _hydration; }
            set { _hydration = value; }
        }
        public int Speed
        {
            get { return _speed; }
            set { _speed = value; }
        }
        public List<CyclistObject> Inventory
        {
            get { return _inventory; }
            set { _inventory = value; }
        }


        #endregion

        #region CONSTRUCTORS

        public Cyclist()
        {
            _cityLocationsVisited = new List<int>();
            _inventory = new List<CyclistObject>();
        }

        public Cyclist(string name, ItemType item, int cityLocationID) : base(name, item, cityLocationID)
        {
            _cityLocationsVisited = new List<int>();
            _inventory = new List<CyclistObject>();
        }

        #endregion
        
        #region METHODS
        
        public bool HasVisited(int _spaceTimeLocationID)
        {
            if (CityLocationsVisited.Contains(_spaceTimeLocationID))
            {
                return true; 
            }
            else
            {
                return false; 
            }
        }

        #endregion
    }
}
