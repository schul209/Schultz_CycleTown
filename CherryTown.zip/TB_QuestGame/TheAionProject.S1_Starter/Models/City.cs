﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TB_QuestGame
{
    /// <summary>
    /// class of the game map
    /// </summary>
    public class City
    {
        #region ***** define all lists to be maintained by the city object *****
        private List<CityLocation> _cityLocations;

        public List<CityLocation> CityLocations
        {
            get { return _cityLocations; }
            set { _cityLocations = value; }
        }



        #endregion

        #region ***** constructor *****

        //
        // default City constructor
        //
        public City()
        {
            //
            // add all of the city objects to the game
            // 
            IntializeCity();
        }

        #endregion

        #region ***** define methods to initialize all game elements *****

        /// <summary>
        /// initialize the city with all of the city locations
        /// </summary>
        private void IntializeCity()
        {
            _cityLocations = CityObjects.CityLocations;
        }

        #endregion

        #region ***** define methods to return game element objects and information *****

        /// <summary>
        /// determine if the City Location Id is valid
        /// </summary>
        /// <param name="cityLocationId">true if city Location exists</param>
        /// <returns></returns>
        public bool IsValidCityLocationId(int cityLocationId)
        {

            List<int> cityLocationIds = new List<int>();

            //
            // create a list of city location ids
            //
            foreach (CityLocation stl in _cityLocations)
            {
                cityLocationIds.Add(stl.CityLocationID);
            }

            //
            // determine if the city location id is a valid id and return the result
            //
            if (cityLocationIds.Contains(cityLocationId))
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// determine if a location is accessible to the player
        /// </summary>
        /// <param name="cityLocationId"></param>
        /// <returns>accessible</returns>
        public bool IsAccessibleLocation(int cityLocationId)
        {
            CityLocation cityLocation = GetCityLocationById(cityLocationId);
            if (cityLocation.Accessable == true)
            {
                return true; 
            }
                else
            {
                return false; 
            }
        }

        /// <summary>
        /// return the next available ID for a CityLocation object
        /// </summary>
        /// <returns>next CityLocationObjectID </returns>
        public int GetMaxCityLocationId()
        {
            int MaxId = 0;
            foreach (CityLocation cityLocation in _cityLocations)
            {
                if (cityLocation.CityLocationID > MaxId)
                {
                    MaxId = cityLocation.CityLocationID;
                }
            }

            return MaxId;
        }

        /// <summary>
        /// get a CityLocation object using an Id
        /// </summary>
        /// <param name="Id">city location ID</param>
        /// <returns>requested city location</returns>
        public CityLocation CityLocationById(int Id)
        {
            CityLocation cityLocation = null;

            //run through list of city locations and grab correct one
            foreach (CityLocation location in _cityLocations)
            {
                if (location.CityLocationID == Id)
                {
                    cityLocation = location;
                }
            }
            //If ID not found in City
            if (cityLocation == null)
            {
                string feedbackMessage = $"The City Location ID {Id} does not exist in the current city.";
                throw new ArgumentException(Id.ToString(), feedbackMessage);
            }

            return cityLocation;
        }

        public bool IsValidCityLocationID(int cityLocationID)
        {
            List<int> cityLocationIds = new List<int>();

            //
            //create a list of city location ids
            //
            foreach (CityLocation stl in _cityLocations)
            {
                cityLocationIds.Add(stl.CityLocationID);
            }
            if (cityLocationIds.Contains(cityLocationID))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public CityLocation GetCityLocationById(int Id)
        {
            CityLocation cityLocation = null;
            //
            //run through list and grab the right one
            //
            foreach (CityLocation location in _cityLocations)
                if (location.CityLocationID == Id)
                {
                    cityLocation = location;
                }

            //
            //the specified ID was not found in the city
            //
            if (cityLocation == null)
            {
                string feedbackMessage = $"The City location ID {Id} does not exist in Cherry Town.";
                throw new ArgumentException(Id.ToString(), feedbackMessage);
            }
            return cityLocation;
        }
        

            #endregion
        
    }
}
