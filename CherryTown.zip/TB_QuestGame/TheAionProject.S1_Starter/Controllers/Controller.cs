﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TB_QuestGame
{
    /// <summary>
    /// controller for the MVC pattern in the application
    /// </summary>
    public class Controller
    {
        #region FIELDS

        private ConsoleView _gameConsoleView;
        private Cyclist _gameCyclist;
        private City _gameCity;
        private bool _playingGame;
        private CityLocation _currentLocation; 
        #endregion

        #region PROPERTIES


        #endregion

        #region CONSTRUCTORS

        public Controller()
        {
            //
            // setup all of the objects in the game
            //
            InitializeGame();

            //
            // begins running the application UI
            //
            ManageGameLoop();
        }

        #endregion

        #region METHODS

        /// <summary>
        /// initialize the major game objects
        /// </summary>
        private void InitializeGame()
        {
            _gameCyclist = new Cyclist();
            _gameCity = new City();
            _gameConsoleView = new ConsoleView (_gameCyclist, _gameCity);
            _playingGame = true;

            Console.CursorVisible = false;
        }

        /// <summary>
        /// method to manage the application setup and game loop
        /// </summary>
        private void ManageGameLoop()
        {
            CyclistAction travelerActionChoice = CyclistAction.None;

            //
            // display splash screen
            //
            _playingGame = _gameConsoleView.DisplaySpashScreen();

            //
            // player chooses to quit
            //
            if (!_playingGame)
            {

                Environment.Exit(1);
            }

            //
            // display introductory message
            //
            _gameConsoleView.DisplayGamePlayScreen("Journey Intro", Text.JourneyIntro(), ActionMenu.JourneyIntro, "");
            _gameConsoleView.GetContinueKey(); 

            //
            // initialize the journey cyclist
            // 
            InitializeJourney();

            //
            // prepare game play screen
            //
            _currentLocation = _gameCity.GetCityLocationById(_gameCyclist.CityLocationId);
            _gameConsoleView.DisplayGamePlayScreen("Current Location", Text.CurrentLocationInfo(_currentLocation), ActionMenu.MainMenu, "");

            //
            //
            // game loop
            //
            while (_playingGame)
            {
                //
                //process all events and stats
                //
                UpdateGameStatus(); 

                travelerActionChoice = _gameConsoleView.GetActionMenuChoice(ActionMenu.MainMenu);

                //
                // choose an action based on the user's menu choice
                //
                switch (travelerActionChoice)
                {
                    case CyclistAction.None:
                        break;

                    case CyclistAction.CyclistInfo:
                        _gameConsoleView.DisplayCyclistInfo();
                        break;

                    case CyclistAction.CyclistUpdate:
                        _gameConsoleView.GetInitialcyclistInfo();
                        break;

                    case CyclistAction.Exit:
                        _playingGame = false;
                        _gameConsoleView.DisplayCyclistExitScreen();
                        Console.ReadLine();

                        break;
                    case CyclistAction.LookAround:
                        _gameConsoleView.DisplayLookAround();
                        break;
                    case CyclistAction.Travel:
                        _gameCyclist.CityLocationId = _gameConsoleView.DisplayGetNextCityLocation();
                        _currentLocation = _gameCity.GetCityLocationById(_gameCyclist.CityLocationId);

                        _gameConsoleView.DisplayGamePlayScreen("Current Location", Text.CurrentLocationInfo
                            (_currentLocation), ActionMenu.MainMenu, "");
                        break;
                    case CyclistAction.CyclistLocationsVisited:
                        _gameConsoleView.DisplayLocationsVisited();
                        break;
                    case CyclistAction.ListCityLocations:
                        _gameConsoleView.DisplayListOfCityLocations();
                        break; 
                    default:
                        break;
                }
            }

            //
            // close the application
            //
            Environment.Exit(1);
        }

        /// <summary>
        /// initialize the player info
        /// </summary>
        private void InitializeJourney()
        {
            Cyclist cyclist = _gameConsoleView.GetInitialcyclistInfo();

            _gameCyclist.Name = cyclist.Name;
            _gameCyclist.nickname = cyclist.nickname;
            _gameCyclist.FitnessLevel = cyclist.FitnessLevel;
            _gameCyclist.Item = cyclist.Item;
            _gameCyclist.AiredTires = cyclist.AiredTires;
            _gameCyclist.Age = cyclist.Age;
            _gameCyclist.IsFast = cyclist.IsFast;
            _gameCyclist.Bike = cyclist.Bike;
            _gameCyclist.CityLocationId = 1;
            _gameCyclist.TotalMinutes = 0;
            _gameCyclist.Hydration = false;
            _gameCyclist.Speed = 10;
        }
        private void UpdateGameStatus()
        {
            if (!_gameCyclist.HasVisited(_currentLocation.CityLocationID))
            {
                //
                //add new location if this is the first visit
                //
                _gameCyclist.CityLocationsVisited.Add(_currentLocation.CityLocationID);
                _gameCyclist.TotalMinutes += _currentLocation.TravelMinutes;
            }
        }

        #endregion
    }
}
