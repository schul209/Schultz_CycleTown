﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TB_QuestGame
{
    /// <summary>
    /// view class
    /// </summary>
    public class ConsoleView
    {
        #region FIELDS

        //
        // declare game objects for the ConsoleView object to use
        //
        Cyclist _gameCyclist;

        #endregion

        #region PROPERTIES

        #endregion

        #region CONSTRUCTORS

        /// <summary>
        /// default constructor to create the console view objects
        /// </summary>
        public ConsoleView(Cyclist gameCyclist)
        {
            _gameCyclist = gameCyclist;

            InitializeDisplay();
        }

        #endregion

        #region METHODS
        /// <summary>
        /// display all of the elements on the game play screen on the console
        /// </summary>
        /// <param name="messageBoxHeaderText">message box header title</param>
        /// <param name="messageBoxText">message box text</param>
        /// <param name="menu">menu to use</param>
        /// <param name="inputBoxPrompt">input box text</param>
        public void DisplayGamePlayScreen(string messageBoxHeaderText, string messageBoxText, Menu menu, string inputBoxPrompt)
        {
            //
            // reset screen to default window colors
            //
            Console.BackgroundColor = ConsoleTheme.WindowBackgroundColor;
            Console.ForegroundColor = ConsoleTheme.WindowForegroundColor;
            Console.Clear();

            ConsoleWindowHelper.DisplayHeader(Text.HeaderText);
            ConsoleWindowHelper.DisplayFooter(Text.FooterText);

            DisplayMessageBox(messageBoxHeaderText, messageBoxText);
            DisplayMenuBox(menu);
            DisplayInputBox();
        }

        /// <summary>
        /// wait for any keystroke to continue
        /// </summary>
        public void GetContinueKey()
        {
            Console.ReadKey();
        }

        /// <summary>
        /// get a action menu choice from the user
        /// </summary>
        /// <returns>action menu choice</returns>
        public CyclistAction GetActionMenuChoice(Menu menu)
        {
            CyclistAction choosenAction = CyclistAction.None;

            //
            // TODO validate menu choices
            //
           
        ConsoleKeyInfo keyPressedInfo = Console.ReadKey();
            char keyPressed = keyPressedInfo.KeyChar;
            choosenAction = menu.MenuChoices[keyPressed];

            return choosenAction;
        }

        /// <summary>
        /// get a string value from the user
        /// </summary>
        /// <returns>string value</returns>
        public string GetString()
        {
            return Console.ReadLine();
        }
        /// <summary>
        /// get a bool value from the user
        /// </summary>
        /// <returns></returns>
        public bool GetBool()
        {
           /* bool validResponse = false;
            DisplayInputBoxPrompt(prompt);

            if (!validResponse)
                {
                ClearInputBox();
                DisplayInputErrorMessage("Please enter true or false.");
                DisplayInputBoxPrompt(prompt);
                }*/
            return bool.Parse(Console.ReadLine());
        }

        /// <summary>
        /// get an integer value from the user
        /// </summary>
        /// <returns>integer value</returns>
        public bool GetInteger(string prompt, int minimumValue, int maximumValue, out int integerChoice)
        {
            bool validResponse = false;
            integerChoice = 0;

            DisplayInputBoxPrompt(prompt);
            while (!validResponse)
            {
                if (int.TryParse(Console.ReadLine(), out integerChoice))
                {
                    if (integerChoice >= minimumValue && integerChoice <= maximumValue)
                    {
                        validResponse = true;
                    }
                    else
                    {
                        ClearInputBox();
                        DisplayInputErrorMessage($"You must enter an integer value between {minimumValue} and {maximumValue}. Please try again.");
                        DisplayInputBoxPrompt(prompt);
                    }
                }
                else
                {
                    ClearInputBox();
                    DisplayInputErrorMessage($"You must enter an integer value between {minimumValue} and {maximumValue}. Please try again.");
                    DisplayInputBoxPrompt(prompt);
                }
            }

            return true;
        }

        /// <summary>
        /// get a character bag item from the user
        /// </summary>
        /// <returns>character race value</returns>
        public Character.ItemType GetItem()
        {
            Character.ItemType itemType;
            Enum.TryParse<Character.ItemType>(Console.ReadLine(), out itemType);

            return itemType;
        }
        /// <summary>
        /// get character bike type
        /// </summary>
        /// <returns></returns>
        public Character.BikeType GetBikeType()
        {
            Character.BikeType bikeType;
            Enum.TryParse<Character.BikeType>(Console.ReadLine(), out bikeType);

            return bikeType;
        }

        /// <summary>
        /// display splash screen
        /// </summary>
        /// <returns>player chooses to play</returns>
        public bool DisplaySpashScreen()
        {
            bool playing = true;
            ConsoleKeyInfo keyPressed;

            Console.BackgroundColor = ConsoleTheme.SplashScreenBackgroundColor;
            Console.ForegroundColor = ConsoleTheme.SplashScreenForegroundColor;
            Console.Clear();
            Console.CursorVisible = false;


            Console.SetCursorPosition(0, 10);
            string tabSpace = new String(' ', 35);
            Console.WriteLine(tabSpace + @" ______________                                 ________                      ");
            Console.WriteLine(tabSpace + @"__  ____/__  /_________________________  __    ___  __/________      ________ ");
            Console.WriteLine(tabSpace + @"_  /    __  __ \  _ \_  ___/_  ___/_  / / /    __  /  _  __ \_ | /| / /_  __ \ ");
            Console.WriteLine(tabSpace + @"/ /___  _  / / /  __/  /   _  /   _  /_/ /     _  /   / /_/ /_ |/ |/ /_  / / /");
            Console.WriteLine(tabSpace + @"\____/  /_/ /_/\___//_/    /_/    _\__, /      /_/    \____/____/|__/ /_/ /_/ ");
            Console.WriteLine(tabSpace + @"                                  /____/                                      ");
            Console.WriteLine(tabSpace + @"                                                                              ");
            Console.WriteLine(tabSpace + @"                                                                              ");

            Console.SetCursorPosition(80, 25);
            Console.Write("Press any key to continue or Esc to exit.");
            keyPressed = Console.ReadKey();
            if (keyPressed.Key == ConsoleKey.Escape)
            {
                playing = false;
            }

            return playing;
        }

        /// <summary>
        /// initialize the console window settings
        /// </summary>
        private static void InitializeDisplay()
        {
            //
            // control the console window properties
            //
            ConsoleWindowControl.DisableResize();
            ConsoleWindowControl.DisableMaximize();
            ConsoleWindowControl.DisableMinimize();
            Console.Title = "Race to Cherry Town";

            //
            // set the default console window values
            //
            ConsoleWindowHelper.InitializeConsoleWindow();

            Console.CursorVisible = false;
        }

        /// <summary>
        /// display the correct menu in the menu box of the game screen
        /// </summary>
        /// <param name="menu">menu for current game state</param>
        private void DisplayMenuBox(Menu menu)
        {
            Console.BackgroundColor = ConsoleTheme.MenuBackgroundColor;
            Console.ForegroundColor = ConsoleTheme.MenuBorderColor;

            //
            // display menu box border
            //
            ConsoleWindowHelper.DisplayBoxOutline(
                ConsoleLayout.MenuBoxPositionTop,
                ConsoleLayout.MenuBoxPositionLeft,
                ConsoleLayout.MenuBoxWidth,
                ConsoleLayout.MenuBoxHeight);

            //
            // display menu box header
            //
            Console.BackgroundColor = ConsoleTheme.MenuBorderColor;
            Console.ForegroundColor = ConsoleTheme.MenuForegroundColor;
            Console.SetCursorPosition(ConsoleLayout.MenuBoxPositionLeft + 2, ConsoleLayout.MenuBoxPositionTop + 1);
            Console.Write(ConsoleWindowHelper.Center(menu.MenuTitle, ConsoleLayout.MenuBoxWidth - 4));

            //
            // display menu choices
            //
            Console.BackgroundColor = ConsoleTheme.MenuBackgroundColor;
            Console.ForegroundColor = ConsoleTheme.MenuForegroundColor;
            int topRow = ConsoleLayout.MenuBoxPositionTop + 3;

            foreach (KeyValuePair<char, CyclistAction> menuChoice in menu.MenuChoices)
            {
                if (menuChoice.Value != CyclistAction.None)
                {
                    string formatedMenuChoice = ConsoleWindowHelper.ToLabelFormat(menuChoice.Value.ToString());
                    Console.SetCursorPosition(ConsoleLayout.MenuBoxPositionLeft + 3, topRow++);
                    Console.Write($"{menuChoice.Key}. {formatedMenuChoice}");
                }
            }
        }

        /// <summary>
        /// display the text in the message box of the game screen
        /// </summary>
        /// <param name="headerText"></param>
        /// <param name="messageText"></param>
        private void DisplayMessageBox(string headerText, string messageText)
        {
            //
            // display the outline for the message box
            //
            Console.BackgroundColor = ConsoleTheme.MessageBoxBackgroundColor;
            Console.ForegroundColor = ConsoleTheme.MessageBoxBorderColor;
            ConsoleWindowHelper.DisplayBoxOutline(
                ConsoleLayout.MessageBoxPositionTop,
                ConsoleLayout.MessageBoxPositionLeft,
                ConsoleLayout.MessageBoxWidth,
                ConsoleLayout.MessageBoxHeight);

            //
            // display message box header
            //
            Console.BackgroundColor = ConsoleTheme.MessageBoxBorderColor;
            Console.ForegroundColor = ConsoleTheme.MessageBoxForegroundColor;
            Console.SetCursorPosition(ConsoleLayout.MessageBoxPositionLeft + 2, ConsoleLayout.MessageBoxPositionTop + 1);
            Console.Write(ConsoleWindowHelper.Center(headerText, ConsoleLayout.MessageBoxWidth - 4));

            //
            // display the text for the message box
            //
            Console.BackgroundColor = ConsoleTheme.MessageBoxBackgroundColor;
            Console.ForegroundColor = ConsoleTheme.MessageBoxForegroundColor;
            List<string> messageTextLines = new List<string>();
            messageTextLines = ConsoleWindowHelper.MessageBoxWordWrap(messageText, ConsoleLayout.MessageBoxWidth - 4);

            int startingRow = ConsoleLayout.MessageBoxPositionTop + 3;
            int endingRow = startingRow + messageTextLines.Count();
            int row = startingRow;
            foreach (string messageTextLine in messageTextLines)
            {
                Console.SetCursorPosition(ConsoleLayout.MessageBoxPositionLeft + 2, row);
                Console.Write(messageTextLine);
                row++;
            }

        }

        /// <summary>
        /// draw the input box on the game screen
        /// </summary>
        public void DisplayInputBox()
        {
            Console.BackgroundColor = ConsoleTheme.InputBoxBackgroundColor;
            Console.ForegroundColor = ConsoleTheme.InputBoxBorderColor;

            ConsoleWindowHelper.DisplayBoxOutline(
                ConsoleLayout.InputBoxPositionTop,
                ConsoleLayout.InputBoxPositionLeft,
                ConsoleLayout.InputBoxWidth,
                ConsoleLayout.InputBoxHeight);
        }

        /// <summary>
        /// display the prompt in the input box of the game screen
        /// </summary>
        /// <param name="prompt"></param>
        public void DisplayInputBoxPrompt(string prompt)
        {
            Console.SetCursorPosition(ConsoleLayout.InputBoxPositionLeft + 4, ConsoleLayout.InputBoxPositionTop + 1);
            Console.ForegroundColor = ConsoleTheme.InputBoxForegroundColor;
            Console.Write(prompt);
            Console.CursorVisible = true;
        }

        /// <summary>
        /// display the error message in the input box of the game screen
        /// </summary>
        /// <param name="errorMessage">error message text</param>
        public void DisplayInputErrorMessage(string errorMessage)
        {
            Console.SetCursorPosition(ConsoleLayout.InputBoxPositionLeft + 4, ConsoleLayout.InputBoxPositionTop + 2);
            Console.ForegroundColor = ConsoleTheme.InputBoxErrorMessageForegroundColor;
            Console.Write(errorMessage);
            Console.ForegroundColor = ConsoleTheme.InputBoxForegroundColor;
            Console.CursorVisible = true;
        }

        /// <summary>
        /// clear the input box
        /// </summary>
        private void ClearInputBox()
        {
            string backgroundColorString = new String(' ', ConsoleLayout.InputBoxWidth - 4);

            Console.ForegroundColor = ConsoleTheme.InputBoxBackgroundColor;
            for (int row = 1; row < ConsoleLayout.InputBoxHeight - 2; row++)
            {
                Console.SetCursorPosition(ConsoleLayout.InputBoxPositionLeft + 4, ConsoleLayout.InputBoxPositionTop + row);
                DisplayInputBoxPrompt(backgroundColorString);
            }
            Console.ForegroundColor = ConsoleTheme.InputBoxForegroundColor;
        }

        /// <summary>
        /// get the player's initial information at the beginning of the game
        /// </summary>
        /// <returns>traveler object with all properties updated</returns>
        public Cyclist GetInitialcyclistInfo()
        {
            Cyclist cyclist = new Cyclist();

            //
            // intro
            //
            DisplayGamePlayScreen("Journey Initialization", Text.InitializeJourneyIntro(), ActionMenu.JourneyIntro, "");
            GetContinueKey();

            //
            // get cyclist's name
            //
            DisplayGamePlayScreen("Journey Initialization - Name", Text.InitializeJourneyGetCyclistName(), ActionMenu.JourneyIntro, "");
            DisplayInputBoxPrompt("Enter your name: ");
            cyclist.Name = GetString();
            //
            //get cyclist's nickname
            //
            DisplayGamePlayScreen("Journey Initialization -nickname", Text.InitializeGetCyclistNickname(cyclist), ActionMenu.JourneyIntro, "");
            DisplayInputBoxPrompt("Enter your nickname below:");
            cyclist.nickname = GetString();
            //
            // get cyclist's fitness level
            //
            DisplayGamePlayScreen("Enter your fitness level on a scale of 1-10:", Text.InitializeJourneyGetCyclistFitnessLevel(cyclist), ActionMenu.JourneyIntro, "");
            int gameCyclistFitnessLevel;

            GetInteger($"Enter your fitness level {cyclist.nickname}: ", 1, 10, out gameCyclistFitnessLevel);
            cyclist.FitnessLevel = gameCyclistFitnessLevel;

            //
            // get cyclist's bag item
            //
            DisplayGamePlayScreen("Journey Initialization - Bag Item", Text.InitializeJourneyGetCyclistItem(cyclist), ActionMenu.JourneyIntro, "");
            DisplayInputBoxPrompt($"Enter your current bag item {cyclist.nickname}: ");
            cyclist.Item = GetItem();

            //
            //get cyclist's air tire value
            //
            DisplayGamePlayScreen("Journey Initialization - Air in Tires", Text.InitializeJourneyGetCyclistAiredTires(cyclist), ActionMenu.JourneyIntro, "");
            DisplayInputBoxPrompt($"Enter true or false if your bike tires are aired up {cyclist.nickname}: ");
            cyclist.AiredTires = GetBool();
            //
            //get cyclist's age
            //
            DisplayGamePlayScreen("Enter your age 1-100:", Text.InitializeJourneyGetCyclistAge(cyclist), ActionMenu.JourneyIntro, "");
            int gameCyclistAge;

            GetInteger($"Enter your age {cyclist.nickname}: ", 1, 100, out gameCyclistAge);
            cyclist.Age = gameCyclistAge;
            //
            //get is cyclist fast
            //
            DisplayGamePlayScreen("Journey Initialization - Cyclist is fast", Text.InitializeJourneyGetCyclistIsFast(cyclist), ActionMenu.JourneyIntro, "");
            DisplayInputBoxPrompt($"Enter true or false if you are fast {cyclist.nickname}: ");
            cyclist.IsFast = GetBool();
            //
            //get cyclist's bike type
            //
            DisplayGamePlayScreen("Journey Initialization - Bike Type", Text.InitializeJourneyGetCyclistBike(cyclist), ActionMenu.JourneyIntro, "");
            DisplayInputBoxPrompt($"Enter your type of bike {cyclist.nickname}: ");
            cyclist.Bike = GetBikeType();
            //
            // echo the cyclist's info
            //
            DisplayGamePlayScreen("Journey Initialization - Complete", Text.InitializeJourneyEchoCyclistInfo(cyclist), ActionMenu.JourneyIntro, "");
           
            GetContinueKey();

            return cyclist;
        }

        #region ----- display responses to menu action choices -----

        public void DisplayCyclistInfo()
        {
            DisplayGamePlayScreen("Cyclist Information", Text.CyclistInfo(_gameCyclist), ActionMenu.MainMenu, "");
        }
        public void DisplayCyclistExitScreen()
        {
            DisplayGamePlayScreen("Exit Game", Text.CyclistExitScreen(_gameCyclist), ActionMenu.MainMenu, "");

        }

        #endregion

        #endregion
    }
}
