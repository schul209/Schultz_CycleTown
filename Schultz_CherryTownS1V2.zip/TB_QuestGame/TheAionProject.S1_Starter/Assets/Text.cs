﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TB_QuestGame
{
    /// <summary>
    /// class to store static and to generate dynamic text for the message and input boxes
    /// </summary>
    public static class Text
    {
        public static List<string> HeaderText = new List<string>() { "Race to Cherry Town" };
        public static List<string> FooterText = new List<string>() { "Thresa Schultz, 2017" };

        #region INTITIAL GAME SETUP

        public static string JourneyIntro()
        {
            string messageBoxText =
            "Oh no! Your car will not start and you need to meet " +
            "your friends at the fesitval at 4:00pm, " +
            "This leaves you 40 minutes to get there. " +
            "Pack what you need on your bike and get going! " +
            "I hope your tires are aired up and you have enough energy to get there. \n" +
            " \n" +
            "Press the Esc key to exit the game at any point.\n" +
            " \n" +
            "Your journey begins now.\n" +
            " \n" +
            "\tYour first task will be to set up the initial parameters of your journey.\n" +
            " \n" +
            "\tPress any key to begin the Process.\n";

            return messageBoxText;
        }

        public static string CurrrentLocationInfo()
        {
            string messageBoxText =
            "You are in Traverse City heading to the Fudgie Festival Downtown. " +
            "Be sure to have enough food and drink to keep your energy up " +
            "for the ride. Your route will depend on how much time you have. " +
            "Be aware of various challenges along the way.\n" +
            " \n" +
            "\tChoose from the menu options to proceed.\n";

            return messageBoxText;
        }

        #region Initialize Journey Text

        public static string InitializeJourneyIntro()
        {
            string messageBoxText =
                "Before you begin your journey enter your trip information.\n" +
                " \n" +
                "Please enter your information below when prompted.\n" +
                " \n" +
                "\tPress any key to begin.";

            return messageBoxText;
        }

        public static string InitializeJourneyGetCyclistName()
        {
            string messageBoxText =
                "Please enter your name below.";

            return messageBoxText;
        }
        public static string InitializeGetCyclistNickname(Cyclist gameCyclist)
        {
            string messageBoxText =
                $"Do you have a nickname {gameCyclist.Name}?\n" +
                 "Please use the name you wish to be referred during your journey.";


            return messageBoxText;
        }
        

        public static string InitializeJourneyGetCyclistFitnessLevel(Cyclist gameCyclist)
        {
            string messageBoxText =
                $"Very good then, we will call you {gameCyclist.nickname} on your journey.\n" +
                " \n" +
                "Enter your fitness level on a scale of 1-10 below.\n" +
                " \n" +
                "Please enter a number between 1 and 10.";

            return messageBoxText;
        }

        public static string InitializeJourneyGetCyclistItem(Cyclist gameCyclist)
        {
            string messageBoxText =
                $"{gameCyclist.nickname}, Please tell what item may already be in your bag.\n" +
                " \n" +
                "Enter your current item in the bag below.\n" +
                " \n" +
                "Please choose from the options given below." +
                " \n";

            string itemList = null;

            foreach (Character.ItemType item in Enum.GetValues(typeof(Character.ItemType)))
            {
                if (item != Character.ItemType.None)
                {
                    itemList += $"\t{item}\n";
                }
            }

            messageBoxText += itemList;

            return messageBoxText;
        }
        public static string InitializeJourneyGetCyclistAiredTires(Cyclist gameCyclist)
        {
            string messageBoxText =
                $"{gameCyclist.nickname}, Do your bike tires have air?\n" +
                "\n" +
                "Please enter true or false below" +
                "\n";

                return messageBoxText;
        }
        public static string InitializeJourneyGetCyclistAge(Cyclist gameCyclist)
        {
            string messageBoxText =
                $"Alright {gameCyclist.nickname}, what is your age?\n" +
                " \n" +
                "Please enter your age below.";

            return messageBoxText;
        }
        public static string InitializeJourneyGetCyclistIsFast(Cyclist gameCyclist)
        {
            string messageBoxText = 
                $"{gameCyclist.nickname}, are you a fast cyclist?\n" +
                "\n" +
                "Or do you like to take your time?\n" +
                "\n" +
                "Please enter true if you are fast, false if not below.";
            return messageBoxText;
        }
        public static string InitializeJourneyGetCyclistBike(Cyclist gameCyclist)
        {
            string messageBoxText =
                $"{gameCyclist.nickname}, What type of bike are you riding?\n" +
                " \n" +
                "Enter your bicycle type.\n" +
                " \n" +
                "Please choose from the options given below." +
                " \n";

            string bikeList = null;

            foreach (Character.BikeType bike in Enum.GetValues(typeof(Character.BikeType)))
            {
                if (bike != Character.BikeType.None)
                {
                    bikeList += $"\t{bike}\n";
                }
            }

            messageBoxText += bikeList;

            return messageBoxText;
        }
       
        public static string InitializeJourneyEchoCyclistInfo(Cyclist gameCyclist)
        {
            string messageBoxText =
                $"Very good then {gameCyclist.nickname}.\n" +
                " \n" +
                "We have gathered the information to start your journey. You will find it" +
                " listed below.\n" +
                " \n" +
                $"\tCyclist Name: {gameCyclist.Name}\n" +
                $"\tCyclist Fitness Level: {gameCyclist.FitnessLevel}\n" +
                $"\tCyclist Bag Item: {gameCyclist.Item}\n" +
                $"\tCyclist Aired Tires: {gameCyclist.AiredTires}\n" +
                $"\tCyclist Age: {gameCyclist.Age}\n" +
                $"\tCyclist Is Fast: {gameCyclist.IsFast}\n" +
                $"\tCyclist Type of Bike: {gameCyclist.Bike}\n" +
                " \n" +
                "Press any key to begin your journey.";

            return messageBoxText;
        }
        

        #endregion

        #endregion

        #region MAIN MENU ACTION SCREENS

        public static string CyclistInfo(Cyclist gameCyclist)
        {
            string messageBoxText =
                $"\tCyclist Name: {gameCyclist.Name}\n" +
                $"\tCyclist Fitness Level: {gameCyclist.FitnessLevel}\n" +
                $"\tCyclist Bag Item: {gameCyclist.Item}\n" +
                $"\tCyclist Aired Tires: {gameCyclist.AiredTires}\n" +
                $"\tCyclist Age: {gameCyclist.Age}\n" +
                $"\tCyclist Is Fast: {gameCyclist.IsFast}\n" +
                $"\tCyclist Type of Bike: {gameCyclist.Bike}\n" +
                " \n";

            return messageBoxText;
        }
        public static string CyclistExitScreen(Cyclist gameCyclist)
        {
            string messageBoxText =
            $"\t{gameCyclist.nickname} You are a quiter!/\n" +
               "\tYou did not meet your friends\n" +
                "\tCome back and play again.\n" +
                "\n" +
                "\tPress enter to continue.";
                
            return messageBoxText;

        }


        //public static string Travel(int currentSpaceTimeLocationId, List<SpaceTimeLocation> spaceTimeLocations)
        //{
        //    string messageBoxText =
        //        $"{gameTraveler.Name}, Aion Base will need to know the name of the new location.\n" +
        //        " \n" +
        //        "Enter the ID number of your desired location from the table below.\n" +
        //        " \n";


        //    string spaceTimeLocationList = null;

        //    foreach (SpaceTimeLocation spaceTimeLocation in spaceTimeLocations)
        //    {
        //        if (race != Character.RaceType.None)
        //        {
        //            raceList += $"\t{race}\n";
        //        }
        //    }

        //    messageBoxText += raceList;

        //    return messageBoxText;
        //}

        #endregion
    }
}
