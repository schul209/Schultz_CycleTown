﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TB_QuestGame
{
    /// <summary>
    /// the character class the player uses in the game
    /// </summary>
    public class Cyclist : Character
    {
        #region ENUMERABLES


        #endregion

        #region FIELDS


        #endregion
        
        #region PROPERTIES
        

        #endregion
        
        #region CONSTRUCTORS

        public Cyclist()
        {

        }

        public Cyclist(string name, ItemType item) : base(name, item)
        {

        }

        #endregion
        
        #region METHODS
        

        #endregion
    }
}
