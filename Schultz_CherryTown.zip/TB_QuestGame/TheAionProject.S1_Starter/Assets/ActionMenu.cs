﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TB_QuestGame
{
    /// <summary>
    /// static class to hold key/value pairs for menu options
    /// </summary>
    public static class ActionMenu
    {
        public static Menu JourneyIntro = new Menu()
        {
            MenuName = "JourneyIntro",
            MenuTitle = "",
            MenuChoices = new Dictionary<char, CyclistAction>()
                    {
                        { ' ', CyclistAction.None }
                    }
        };

        public static Menu IntitializeJourney = new Menu()
        {
            MenuName = "InitializeJourney",
            MenuTitle = "Initialize Journey",
            MenuChoices = new Dictionary<char, CyclistAction>()
                {
                    { '1', CyclistAction.Exit }
                }
        };

        public static Menu MainMenu = new Menu()
        {
            MenuName = "MainMenu",
            MenuTitle = "Main Menu",
            MenuChoices = new Dictionary<char, CyclistAction>()
                {
                    { '1', CyclistAction.CyclistInfo },
                    { '2', CyclistAction.Exit }
                }
        };

        //public static Menu ManageTraveler = new Menu()
        //{
        //    MenuName = "ManageTraveler",
        //    MenuTitle = "Manage Traveler",
        //    MenuChoices = new Dictionary<char, PlayerAction>()
        //            {
        //                PlayerAction.MissionSetup,
        //                PlayerAction.TravelerInfo,
        //                PlayerAction.Exit
        //            }
        //};
    }
}
