﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TB_QuestGame
{

    /// <summary>
    /// static class to hold all objects in the game city; locations, game objects, npc's
    /// </summary>
    public static partial class CityObjects
    {
        public static List<CityLocation> CityLocations = new List<CityLocation>()
        {
            new CityLocation
            {
                CommonName = "Home", 
                CityLocationID = 1, 
                UniversalLocation = "Start", 
                Description = "Home sweet home, fortunately just an easy bike ride away from downtown..." +
                    "hopefully. You are in Traverse City heading to the Cherry Festival Downtown to meet" +
                    "your friends. Be sure to have enough food and drink to keep your energy up" +
                    "for the ride. Your route will depend on how much time you have.\n" ,
                GeneralContents = "Your bike and your broken down car. Basic living necessities.", 
                Accessable = true, 
                TravelMinutes = 0
            },
            new CityLocation
            {
                CommonName = "Tart Cherry Trail",
                CityLocationID = 2,
                UniversalLocation = "East Side",
                Description = "The Tart Cherry Trail located in " +
                    "the city of Traverse City on the east side of town. " +
                    "This is a main cross town route for pedestrians and the beginning of the journey.\n",
                GeneralContents = "The trail is a quite scenic area " +
                    "with a bike shop along the way and a few critters here and there. " +
                    "It is often busy with other pedestrians. \n",
                Accessable = true,
                TravelMinutes = 7
            },
            new CityLocation
            {
                CommonName = "Boardman Bridge",
                CityLocationID = 3,
                UniversalLocation = "Old Towne",
                Description = "Boardman Bridge is a lovely pedestrian crossing of " +
                    "the Boardman River. There are a few sharp turns and it is slightly out of the way.\n",
                GeneralContents = "Beware of the Bridge Troll named Brian, he may require cookies to pass. \n",
                Accessable = false,
                TravelMinutes = 8
            },
            new CityLocation
            {
                CommonName = "Railroad Avenue",
                CityLocationID = 4,
                UniversalLocation = "Central",
                Description = "Railroad Avenue is a route that feeds into the quiet Central neighborhoods " +
                    "it is where the Tart Cherry trail ends if heading into downtown proper.\n",
                GeneralContents = "There is a lemon-aid stand along the way here but they only accept cherry tokens. \n",
                Accessable = true,
                TravelMinutes = 7
            },
            new CityLocation
            {
                CommonName = "Eighth Street",
                CityLocationID = 5,
                UniversalLocation = "The Pits",
                Description = "The dreaded Eighth street route can be faster but" +
                    "treacherous with pot-holes the size of your bike and terrible drivers.\n",
                GeneralContents = "Potholes, lots of potholes and traffic. \n", 
                   
                Accessable = true,
                TravelMinutes = 7
                },
            new CityLocation
            {
                CommonName = "Central neighborhoods",
                CityLocationID = 6,
                UniversalLocation = "Central",
                Description = "The central neighborhoods are usually quiet and have light traffic," +
                    "this week however is Festival week so this may not be true. \n",
                GeneralContents = "There happens to be a parade today and this route is filled with" +
                    "marching bands and their busses as line up for the parade. Navigate slowly.",
                Accessable = false,
                TravelMinutes = 8
                },
            new CityLocation
            {
                CommonName = "Bay Trail",
                CityLocationID = 7,
                UniversalLocation = "Downtown",
                Description = "You are so close to your destination but there are many" +
                    "festival goers on this route. Try not to hit anyone, you must be patient.\n",
                GeneralContents = "There are pedestrians, children, strollers, you name it, it's here.",
                Accessable = false,
                TravelMinutes = 8,
            },
            new CityLocation
            {
                CommonName = "Zoo Tunnel",
                CityLocationID = 8,
                UniversalLocation = "Downtown",
                Description = "You are moments away from meeting your friends, you just have to get" +
                    "through the creepy tunnel and not get distracted with the food and sights along the way.",
                GeneralContents = "Bijou the ghost is known to lurk in this tunnel, legend has it the ghost likes cherries" +
                    "or movie tickets.\n",
                Accessable = true,
                TravelMinutes = 7,
            },
            new CityLocation
            {
                CommonName = "Open Space",
                CityLocationID = 9,
                UniversalLocation = "Your Destination",
                Description = "Your friends are waiting for you here to enjoy the festivities for the" +
                    "evening.\n",
                GeneralContents = "Food, friends, entertainment and a great view. Sit on the beach and enjoy your summer evening.\n",
                Accessable = false,
                TravelMinutes = 0,
               }
            };
            }

        }
        


