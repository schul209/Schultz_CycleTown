﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TB_QuestGame
{
    /// <summary>
    /// static class to hold key/value pairs for menu options
    /// </summary>
    public static class ActionMenu
    {
        public enum CurrentMenu
        {
            None, 
            MissionIntro, 
            InitializeMission, 
            MainMenu, 
            AdminMenu
        }
        public static CurrentMenu currentMenu = CurrentMenu.MainMenu;

        
        public static Menu JourneyIntro = new Menu()
        {
            MenuName = "JourneyIntro",
            MenuTitle = "",
            MenuChoices = new Dictionary<char, CyclistAction>()
                    {
                        { ' ', CyclistAction.None }
                    }
        };

        public static Menu IntitializeJourney = new Menu()
        {
            MenuName = "InitializeJourney",
            MenuTitle = "Initialize Journey",
            MenuChoices = new Dictionary<char, CyclistAction>()
                {
                    { '1', CyclistAction.Exit }
                }
        };

        public static Menu MainMenu = new Menu()
        {
            MenuName = "MainMenu",
            MenuTitle = "Main Menu",
            MenuChoices = new Dictionary<char, CyclistAction>()
                {
                    { '1', CyclistAction.CyclistInfo },
                    { '2', CyclistAction.LookAround },
                    { '3', CyclistAction.LookAt },
                    { '4', CyclistAction.PickUp },
                    { '5', CyclistAction.PutDown  },
                    { '6', CyclistAction.Inventory },
                    { '7', CyclistAction.Travel },
                    { '8', CyclistAction.CyclistLocationsVisited },
                    { '9', CyclistAction.AdminMenu },
                    {'0', CyclistAction.Exit }
                }
        };

        public static Menu AdminMenu = new Menu()
        {
            MenuName = "AdminMenu",
            MenuTitle = "Admin Menu",
            MenuChoices = new Dictionary<char, CyclistAction>()
                {
                    { '1', CyclistAction.ListCityLocations },
                    { '2', CyclistAction.ListAllGameObjects},
                    { '3', CyclistAction.CyclistUpdate },
                    { '0', CyclistAction.ReturnToMainMenu }
                }
        };


        //public static Menu ManageTraveler = new Menu()
        //{
        //    MenuName = "ManageTraveler",
        //    MenuTitle = "Manage Traveler",
        //    MenuChoices = new Dictionary<char, PlayerAction>()
        //            {
        //                PlayerAction.MissionSetup,
        //                PlayerAction.TravelerInfo,
        //                PlayerAction.Exit
        //            }
        //};
    }
}
