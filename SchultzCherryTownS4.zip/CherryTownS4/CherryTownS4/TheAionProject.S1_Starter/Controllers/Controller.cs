﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TB_QuestGame
{
    /// <summary>
    /// controller for the MVC pattern in the application
    /// </summary>
    public class Controller
    {
        #region FIELDS

        private ConsoleView _gameConsoleView;
        private Cyclist _gameCyclist;
        private City _gameCity;
        private bool _playingGame;
        private CityLocation _currentLocation; 
        #endregion

        #region PROPERTIES


        #endregion

        #region CONSTRUCTORS

        public Controller()
        {
            //
            // setup all of the objects in the game
            //
            InitializeGame();

            //
            // begins running the application UI
            //
            ManageGameLoop();
        }

        #endregion

        #region METHODS

        /// <summary>
        /// initialize the major game objects
        /// </summary>
        private void InitializeGame()
        {
            _gameCyclist = new Cyclist();
            _gameCity = new City();
            _gameConsoleView = new ConsoleView (_gameCyclist, _gameCity);
            _playingGame = true;

            //
            //add initial inventory items
            //
            _gameCyclist.Inventory.Add(_gameCity.GetGameObjectById(4) as CyclistObject);
            _gameCyclist.Inventory.Add(_gameCity.GetGameObjectById(5) as CyclistObject);

            Console.CursorVisible = false;
        }

        /// <summary>
        /// method to manage the application setup and game loop
        /// </summary>
        private void ManageGameLoop()
        {
            CyclistAction cyclistActionChoice = CyclistAction.None;

            //
            // display splash screen
            //
            _playingGame = _gameConsoleView.DisplaySpashScreen();

            //
            // player chooses to quit
            //
            if (!_playingGame)
            {

                Environment.Exit(1);
            }

            //
            // display introductory message
            //
            _gameConsoleView.DisplayGamePlayScreen("Journey Intro", Text.JourneyIntro(), ActionMenu.JourneyIntro, "");
            _gameConsoleView.GetContinueKey(); 

            //
            // initialize the journey cyclist
            // 
            InitializeJourney();

            //
            // prepare game play screen
            //
            _currentLocation = _gameCity.GetCityLocationById(_gameCyclist.CityLocationId);
            _gameConsoleView.DisplayGamePlayScreen("Current Location", Text.CurrentLocationInfo(_currentLocation), ActionMenu.MainMenu, "");

            //
            //
            // game loop
            //
            while (_playingGame)
            {
                //
                //process all events and stats
                //
                UpdateGameStatus();
                
                //
                //get game action from player
                //
                cyclistActionChoice = GetNextCyclistAction();
                /*if (ActionMenu.currentMenu == ActionMenu.CurrentMenu.MainMenu)
                {
                    cyclistActionChoice = _gameConsoleView.GetActionMenuChoice(ActionMenu.MainMenu);
                }
                else if (ActionMenu.currentMenu == ActionMenu.CurrentMenu.ObjectMenu)
                {
                    cyclistActionChoice = _gameConsoleView.GetActionMenuChoice(ActionMenu.ObjectMenu);
                }
                else if (ActionMenu.currentMenu == ActionMenu.CurrentMenu.NpcMenu)
                {
                    cyclistActionChoice = _gameConsoleView.GetActionMenuChoice(ActionMenu.NpcMenu);
                }
                else if (ActionMenu.currentMenu == ActionMenu.CurrentMenu.CyclistMenu)
                {
                    cyclistActionChoice = _gameConsoleView.GetActionMenuChoice(ActionMenu.CyclistMenu);
                }
                else if (ActionMenu.currentMenu == ActionMenu.CurrentMenu.CyclistMenu)
                {
                    cyclistActionChoice = _gameConsoleView.GetActionMenuChoice(ActionMenu.AdminMenu);
                }*/

                //
                // choose an action based on the user's menu choice
                //
                switch (cyclistActionChoice)
                {
                    case CyclistAction.None:
                        break;

                    case CyclistAction.CyclistInfo:
                        _gameConsoleView.DisplayCyclistInfo();
                        break;

                    case CyclistAction.CyclistUpdate:
                        _gameConsoleView.GetInitialcyclistInfo();
                        break;

                    case CyclistAction.Exit:
                        _playingGame = false;
                        _gameConsoleView.DisplayCyclistExitScreen();
                        Console.ReadLine();

                        break;
                    case CyclistAction.LookAround:
                        _gameConsoleView.DisplayLookAround();
                        break;
                    case CyclistAction.LookAt:
                        LookAtAction();
                        break; 
                    case CyclistAction.Travel:
                        _gameCyclist.CityLocationId = _gameConsoleView.DisplayGetNextCityLocation();
                        _currentLocation = _gameCity.GetCityLocationById(_gameCyclist.CityLocationId);

                        _gameConsoleView.DisplayGamePlayScreen("Current Location", Text.CurrentLocationInfo
                            (_currentLocation), ActionMenu.MainMenu, "");
                        break;
                    case CyclistAction.CyclistLocationsVisited:
                        _gameConsoleView.DisplayLocationsVisited();
                        break;
                    case CyclistAction.ListCityLocations:
                        _gameConsoleView.DisplayListOfCityLocations();
                        break;
                    case CyclistAction.ListAllGameObjects:
                        _gameConsoleView.DisplayListOfAllGameObjects();
                        break;
                    case CyclistAction.ListNonPlayerCharacters:
                        _gameConsoleView.DisplayListOfAllNpcObjects();
                        break; 
                    case CyclistAction.AdminMenu:
                        ActionMenu.currentMenu = ActionMenu.CurrentMenu.AdminMenu;
                        _gameConsoleView.DisplayGamePlayScreen("Admin Menu", "Select an operation from the menu.", ActionMenu.AdminMenu, "");
                        break;
                    case CyclistAction.CyclistMenu:
                        ActionMenu.currentMenu = ActionMenu.CurrentMenu.CyclistMenu;
                        _gameConsoleView.DisplayGamePlayScreen("Cyclist Menu", "Select an option from the menu.",
                            ActionMenu.CyclistMenu, "");
                        break;
                    case CyclistAction.ObjectMenu:
                        ActionMenu.currentMenu = ActionMenu.CurrentMenu.ObjectMenu;
                        _gameConsoleView.DisplayGamePlayScreen("Object Menu", "Select an option from the menu.",
                            ActionMenu.ObjectMenu, "");
                        break;
                    case CyclistAction.NonPlayerCharacterMenu:
                        ActionMenu.currentMenu = ActionMenu.CurrentMenu.NpcMenu;
                        _gameConsoleView.DisplayGamePlayScreen("NPC Menu", "Select an option from the menu.",
                            ActionMenu.NpcMenu, "");
                        break; 

                    case CyclistAction.ReturnToMainMenu:
                        ActionMenu.currentMenu = ActionMenu.CurrentMenu.MainMenu;
                        _gameConsoleView.DisplayGamePlayScreen("Current Location", Text.CurrentLocationInfo(_currentLocation), ActionMenu.MainMenu, "");
                        break;
                    case CyclistAction.Inventory:
                        _gameConsoleView.DisplayInventory();
                        break;
                    case CyclistAction.PutDown:
                        PutDownAction();
                        break;
                    case CyclistAction.TalkTo:
                        TalkToAction();
                        break; 
                    default:
                    case CyclistAction.PickUp:
                        PickUpAction();
                        break; 
                        break;
                }
            }

            //
            // close the application
            //
            Environment.Exit(1);
        }

        /// <summary>
        /// initialize the player info
        /// </summary>
        private void InitializeJourney()
        {
            Cyclist cyclist = _gameConsoleView.GetInitialcyclistInfo();

            _gameCyclist.Name = cyclist.Name;
            _gameCyclist.nickname = cyclist.nickname;
            _gameCyclist.FitnessLevel = cyclist.FitnessLevel;
            _gameCyclist.Item = cyclist.Item;
            _gameCyclist.AiredTires = cyclist.AiredTires;
            _gameCyclist.Age = cyclist.Age;
            _gameCyclist.IsFast = cyclist.IsFast;
            _gameCyclist.Bike = cyclist.Bike;
            _gameCyclist.CityLocationId = 1;
            _gameCyclist.TotalMinutes = 0;
            _gameCyclist.Hydration = false;
            _gameCyclist.Speed = 10;
        }
        private void UpdateGameStatus()
        {
            if (!_gameCyclist.HasVisited(_currentLocation.CityLocationID))
            {
                //
                //add new location if this is the first visit
                //
                _gameCyclist.CityLocationsVisited.Add(_currentLocation.CityLocationID);
                _gameCyclist.TotalMinutes += _currentLocation.TravelMinutes;
            }
            
        }
        private void LookAtAction()
        {   //
            //list traveler objects list in location and get a player choice
            //
            int gameobjectToLookAtId = _gameConsoleView.DisplayGetGameObjectsToLookAt();
            //
            //show game object info
            //
            if (gameobjectToLookAtId != 0)
            {
                //
                //get the object from the City
                //
                GameObject gameObject = _gameCity.GetGameObjectById(gameobjectToLookAtId);

                //
                //display object information
                //
                _gameConsoleView.DisplayGameObjectInfo(gameObject);
            }
        }
        /// <summary>
        /// process the Pick Up action
        /// </summary>
        private void PickUpAction()
        {
            //
            // display a list of cyclist objects in city location and get a player choice
            //
            int cyclistObjectToPickUpId = _gameConsoleView.DisplayGetCyclistObjectToPickUp();

            //
            // add the cyclist object to cyclist's inventory
            //
            if (cyclistObjectToPickUpId != 0)
            {
                //
                // get the game object from the city
                //
                CyclistObject cyclistObject = _gameCity.GetGameObjectById(cyclistObjectToPickUpId) as CyclistObject;

                //
                // note: cyclist object is added to list and the city location is set to 0
                //
                _gameCyclist.Inventory.Add(cyclistObject);
                cyclistObject.CityLocationId = 0;

                //
                // display confirmation message
                //
                _gameConsoleView.DisplayConfirmCyclistObjectAddedToInventory(cyclistObject);
            }
        }
        private void PutDownAction()
        {
            //
            //display cyclist object list and get user choice
            //
            int inventoryObjectToPutDownID = _gameConsoleView.DisplayGetInventoryObjectToPutDown();

            //
            //get game object from the city
            //
            CyclistObject cyclistObject = _gameCity.GetGameObjectById(inventoryObjectToPutDownID) as CyclistObject;

            //
            //remove the object from inventory and reset the location id
            //
            _gameCyclist.Inventory.Remove(cyclistObject);
            cyclistObject.CityLocationId = _gameCyclist.CityLocationId;
            //
            //display confirmation
            //
            _gameConsoleView.DisplayConfirmCyclistObjectRemovedFromInventory(cyclistObject);


        }
        private CyclistAction GetNextCyclistAction()
        {
            CyclistAction CyclistActionChoice = CyclistAction.None;

            switch (ActionMenu.currentMenu)
            {
                case ActionMenu.CurrentMenu.MainMenu:
                    CyclistActionChoice = _gameConsoleView.GetActionMenuChoice(ActionMenu.MainMenu);
                    break;
                case ActionMenu.CurrentMenu.ObjectMenu:
                    CyclistActionChoice = _gameConsoleView.GetActionMenuChoice(ActionMenu.ObjectMenu);
                    break;
                case ActionMenu.CurrentMenu.NpcMenu:
                    CyclistActionChoice = _gameConsoleView.GetActionMenuChoice(ActionMenu.NpcMenu);
                    break;
                case ActionMenu.CurrentMenu.CyclistMenu:
                    CyclistActionChoice = _gameConsoleView.GetActionMenuChoice(ActionMenu.CyclistMenu);
                    break;
                case ActionMenu.CurrentMenu.AdminMenu:
                    CyclistActionChoice = _gameConsoleView.GetActionMenuChoice(ActionMenu.AdminMenu);
                    break;
                default:
                    break;
            }
            return CyclistActionChoice;
        }
        private void TalkToAction()
        {
            //
            //display a list of NPCs in the city & get player choice
            //
            int npcToTalkToId = _gameConsoleView.DisplayGetNpcToTalkTo();

            //
            //display NPC's message
            //
            if (npcToTalkToId !=0)
            {
                //
                //get NPC from the City
                //
                Npc npc = _gameCity.GetNpcById(npcToTalkToId);
                //
                //display info for the object chosen
                //
                _gameConsoleView.DisplayTalkTo(npc);

            }
        }

        #endregion
    }
}
