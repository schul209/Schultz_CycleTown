﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TB_QuestGame
{
    /// <summary>
    /// static class to hold key/value pairs for menu options
    /// </summary>
    public static class ActionMenu
    {
        public enum CurrentMenu
        {
            None, 
            MissionIntro, 
            InitializeMission, 
            MainMenu, 
            ObjectMenu, 
            NpcMenu, 
            CyclistMenu,
            AdminMenu
        }
        public static CurrentMenu currentMenu = CurrentMenu.MainMenu;

        
        public static Menu JourneyIntro = new Menu()
        {
            MenuName = "JourneyIntro",
            MenuTitle = "",
            MenuChoices = new Dictionary<char, CyclistAction>()
                    {
                        { ' ', CyclistAction.None }
                    }
        };

        public static Menu IntitializeJourney = new Menu()
        {
            MenuName = "InitializeJourney",
            MenuTitle = "Initialize Journey",
            MenuChoices = new Dictionary<char, CyclistAction>()
                {
                    { '1', CyclistAction.Exit }
                }
        };

        public static Menu MainMenu = new Menu()
        {
            MenuName = "MainMenu",
            MenuTitle = "Main Menu",
            MenuChoices = new Dictionary<char, CyclistAction>()
                {
                    { '1', CyclistAction.LookAround },
                    { '2', CyclistAction.Travel },
                    { '3', CyclistAction.ObjectMenu },
                    { '4', CyclistAction.NonPlayerCharacterMenu },
                    { '5', CyclistAction.CyclistMenu  },
                    { '6', CyclistAction.AdminMenu },
                    { '0', CyclistAction.Exit },
                }
        };
        public static Menu CyclistMenu = new Menu()
        {
            MenuName = "CyclistMenu",
            MenuTitle = "Cyclist Menu",
            MenuChoices = new Dictionary<char, CyclistAction>()
            {
                { '1', CyclistAction.CyclistInfo },
                { '2', CyclistAction.Inventory },
                { '3', CyclistAction.CyclistLocationsVisited },
                { '0', CyclistAction.ReturnToMainMenu }
            }

        };
        public static Menu ObjectMenu = new Menu()
        {
            MenuName = "ObjectMenu",
            MenuTitle = "Object Menu",
            MenuChoices = new Dictionary<char, CyclistAction>()
            {
                { '1', CyclistAction.LookAt },
                { '2', CyclistAction.PickUp },
                { '3', CyclistAction.PutDown },
                { '0', CyclistAction.ReturnToMainMenu }
            }
        };
        public static Menu NpcMenu = new Menu()
        {
            MenuName = "NpcMenu",
            MenuTitle = "NPC Menu",
            MenuChoices = new Dictionary<char, CyclistAction>()
            {
                { '1', CyclistAction.TalkTo },
                { '0', CyclistAction.ReturnToMainMenu }
            }
        };

        public static Menu AdminMenu = new Menu()
        {
            MenuName = "AdminMenu",
            MenuTitle = "Admin Menu",
            MenuChoices = new Dictionary<char, CyclistAction>()
                {
                    { '1', CyclistAction.ListCityLocations },
                    { '2', CyclistAction.ListAllGameObjects},
                    { '3', CyclistAction.CyclistUpdate },
                    { '4', CyclistAction.ListNonPlayerCharacters },
                    { '0', CyclistAction.ReturnToMainMenu }
                }
        };


        //public static Menu ManageTraveler = new Menu()
        //{
        //    MenuName = "ManageTraveler",
        //    MenuTitle = "Manage Traveler",
        //    MenuChoices = new Dictionary<char, PlayerAction>()
        //            {
        //                PlayerAction.MissionSetup,
        //                PlayerAction.TravelerInfo,
        //                PlayerAction.Exit
        //            }
        //};
    }
}
