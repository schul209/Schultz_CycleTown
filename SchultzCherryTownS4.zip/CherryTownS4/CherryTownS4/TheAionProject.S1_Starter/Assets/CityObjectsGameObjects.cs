﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TB_QuestGame
{
    public static partial class CityObjects
    {
        public static List<GameObject> GameObjects = new List<GameObject>()
        {
        new CyclistObject
            {
              Id = 1,
              Name = "Cherries",
              CityLocationId = 2,
              Description = "A cup of Traverse City Cherries",
              Type = CyclistObjectType.Food,
              TravelMinutes  = -2,
              CanInventory = true,
              IsConsumable = true,
              IsVisible = true
            },
        new CyclistObject
           {
            Id = 2,
            Name = "Aqua Sphere",
            CityLocationId = 3,
            Description = "An edible sphere of water",
            Type = CyclistObjectType.Water,
            TravelMinutes = -2,
            CanInventory = true,
            IsConsumable = true,
            IsVisible = true
           },
        new CyclistObject
        {
            Id = 3,
            Name = "Tire pump",
            CityLocationId = 5,
            Description = "Air pump for your tires",
            Type = CyclistObjectType.Tool,
            TravelMinutes = -3,
            CanInventory = true,
            IsConsumable = true,
            IsVisible = true

        },
        new CyclistObject
        {
            Id = 4,
            Name = "Bike",
            CityLocationId = 0,
            Description = "Your transportation",
            Type = CyclistObjectType.Tool,
            TravelMinutes = 0,
            CanInventory = true,
            IsConsumable = false,
            IsVisible = true
        },
        new CyclistObject
        {
            Id = 5,
            Name = "High Frequency bike bell",
            CityLocationId = 0,
            Description = "Defensive mechanism for defeating crowds, traffic and various other riff-raff",
            Type = CyclistObjectType.Tool,
            TravelMinutes = 0,
            CanInventory = true,
            IsConsumable = false,
            IsVisible = true
        },
        new CyclistObject
        {
            Id = 6,
            Name = "Water Bottle",
            CityLocationId = 1, 
            Description = "Water for the road.",
            Type = CyclistObjectType.Water, 
            TravelMinutes = -2, 
            CanInventory = true, 
            IsConsumable = true, 
            IsVisible = true
        },
        new CyclistObject
        {
            Id = 7, 
            Name = "Cherry Tokens", 
            CityLocationId = 4,
            Description = "Currency for select items.", 
            Type = CyclistObjectType.currency, 
            TravelMinutes = -1, 
            CanInventory = true, 
            IsConsumable = true, 
            IsVisible = true

        },
        new CyclistObject
        {
            Id = 8, 
            Name = "Cherry power bites", 
            CityLocationId = 8, 
            Description = "Cherry flavored energy bites.",
            Type = CyclistObjectType.Food, 
            TravelMinutes = -2, 
            CanInventory = true, 
            IsConsumable = true, 
            IsVisible = true
        },
        new CyclistObject
        {   Id = 9, 
            Name = "Lemonade",
            CityLocationId = 6, 
            Description = "Young entrepreneurs selling a delicious summer beverage", 
            Type = CyclistObjectType.Water, 
            TravelMinutes = -2, 
            CanInventory = false, 
            IsConsumable = true
        },
        new CyclistObject
        {
            Id = 10, 
            Name = "Cheap Sunglasses", 
            CityLocationId = 7, 
            Description = "Almost there, slow down and enjoy the view, the shades out to help.", 
            Type = CyclistObjectType.Tool, 
            TravelMinutes = 0, 
            CanInventory = true
        }


              };

            }
    }

