﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TB_QuestGame
{
    public static partial class CityObjects
    {
        public static List<Npc> Npcs = new List<Npc>()
        {
            new People
            {
                Id= 1,
                Name = "Bridge Troll",
                CityLocationId = 3,
                Description = "A bridge that resides under the Boardman Bridge, he looks hungry.",
                Messages = new List<string>
                {
                "Hello cyclist, I see that you wish to pass.",
                "I see you have a bag with you.",
                "Do you have anything in there for me?"
                }
            },
            new People
            {
                Id = 2,
                Name = "Scurrying Rabbit",
                CityLocationId = 2,
                Description = "Look out for small critters running around on the trail.",
                Messages = new List<string>
                {
                "Hey! watch where you're going!"
                }
            }, 
            new People
            {
                Id = 3,
                Name= "Jack",
                CityLocationId = 6, 
                Description = "The maker of the Cherry Town's best lemonaide.",
                Messages = new List<string>
                {
                    "Would you like some lemonaide?",
                    "Lemonaide is 1 cherry token.",
                }
            }
        };
    }
}