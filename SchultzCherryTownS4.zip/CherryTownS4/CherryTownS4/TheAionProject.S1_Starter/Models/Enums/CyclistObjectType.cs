﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TB_QuestGame
{
    
        public enum CyclistObjectType
        {
            Cherries,
            Water, 
            Food, 
            Tool, 
            currency, 
            none
        }
}
