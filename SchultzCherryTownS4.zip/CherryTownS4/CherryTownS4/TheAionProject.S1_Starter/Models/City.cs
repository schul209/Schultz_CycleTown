﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TB_QuestGame
{
    /// <summary>
    /// class of the game map
    /// </summary>
    public class City
    {
        #region ***** define all lists to be maintained by the city object *****
        private List<CityLocation> _cityLocations;
        private List<GameObject> _gameObjects;
        private List<Npc> _npcs;

        public List<Npc> Npcs
        {
            get { return _npcs; }
            set { _npcs = value; }
        }

        public List<GameObject> GameObjects
        {
            get { return _gameObjects; }
            set { _gameObjects = value; }
        }


        public List<CityLocation> CityLocations
        {
            get { return _cityLocations; }
            set { _cityLocations = value; }
        }



        #endregion

        #region ***** constructor *****

        //
        // default City constructor
        //
        public City()
        {
            //
            // add all of the city objects to the game
            // 
            IntializeCity();
        }

        #endregion

        #region ***** define methods to initialize all game elements *****

        /// <summary>
        /// initialize the city, game objects and Npcs with all of the city locations
        /// </summary>
        private void IntializeCity()
        {
            _cityLocations = CityObjects.CityLocations;
            _gameObjects = CityObjects.GameObjects;
            _npcs = CityObjects.Npcs;
        }

        #endregion

        #region ***** define methods to return game element objects and information *****

        /// <summary>
        /// determine if the City Location Id is valid
        /// </summary>
        /// <param name="cityLocationId">true if city Location exists</param>
        /// <returns></returns>
        public bool IsValidCityLocationId(int cityLocationId)
        {

            List<int> cityLocationIds = new List<int>();

            //
            // create a list of city location ids
            //
            foreach (CityLocation stl in _cityLocations)
            {
                cityLocationIds.Add(stl.CityLocationID);
            }

            //
            // determine if the city location id is a valid id and return the result
            //
            if (cityLocationIds.Contains(cityLocationId))
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// determine if a location is accessible to the player
        /// </summary>
        /// <param name="cityLocationId"></param>
        /// <returns>accessible</returns>
        public bool IsAccessibleLocation(int cityLocationId)
        {
            CityLocation cityLocation = GetCityLocationById(cityLocationId);
            if (cityLocation.Accessable == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// return the next available ID for a CityLocation object
        /// </summary>
        /// <returns>next CityLocationObjectID </returns>
        public int GetMaxCityLocationId()
        {
            int MaxId = 0;
            foreach (CityLocation cityLocation in _cityLocations)
            {
                if (cityLocation.CityLocationID > MaxId)
                {
                    MaxId = cityLocation.CityLocationID;
                }
            }

            return MaxId;
        }

        /// <summary>
        /// get a CityLocation object using an Id
        /// </summary>
        /// <param name="Id">city location ID</param>
        /// <returns>requested city location</returns>
        public CityLocation CityLocationById(int Id)
        {
            CityLocation cityLocation = null;

            //run through list of city locations and grab correct one
            foreach (CityLocation location in _cityLocations)
            {
                if (location.CityLocationID == Id)
                {
                    cityLocation = location;
                }
            }
            //If ID not found in City
            if (cityLocation == null)
            {
                string feedbackMessage = $"The City Location ID {Id} does not exist in the current city.";
                throw new ArgumentException(Id.ToString(), feedbackMessage);
            }

            return cityLocation;
        }
        /// <summary>
        /// determine if the location ID is Valid
        /// </summary>
        /// <param name="cityLocationID"></param>
        /// <returns></returns>
        public bool IsValidCityLocationID(int cityLocationID)
        {
            List<int> cityLocationIds = new List<int>();

            //
            //create a list of city location ids
            //
            foreach (CityLocation stl in _cityLocations)
            {
                cityLocationIds.Add(stl.CityLocationID);
            }
            if (cityLocationIds.Contains(cityLocationID))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// Get the City location by ID
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public CityLocation GetCityLocationById(int Id)
        {
            CityLocation cityLocation = null;
            //
            //run through list and grab the right one
            //
            foreach (CityLocation location in _cityLocations)
                if (location.CityLocationID == Id)
                {
                    cityLocation = location;
                }

            //
            //the specified ID was not found in the city
            //
            if (cityLocation == null)
            {
                string feedbackMessage = $"The City location ID {Id} does not exist in Cherry Town.";
                throw new ArgumentException(Id.ToString(), feedbackMessage);
            }
            return cityLocation;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="gameObjectId"></param>
        /// <param name="currentCityLocation"></param>
        /// <returns></returns>
        public bool IsValidGameObjectByLocationId(int gameObjectId, int currentCityLocation)
        {
            List<int> gameObjectIds = new List<int>();

            //
            //creat a list of game object ids in current city location
            //
            foreach (GameObject gameObject in _gameObjects)
            {
                if (gameObject.CityLocationId == currentCityLocation)
                {
                    gameObjectIds.Add(gameObject.Id);
                }
            }
         //
        // Is the game object id a valid ID? If so return the result
        //
        if (gameObjectIds.Contains(gameObjectId))
            {
                return true;
            }
        else
            {
                return false; 
            }
        }
        /// <summary>
        /// Create list of object id's in current location, validate, return result
        /// </summary>
        /// <param name="cyclistObjectId"></param>
        /// <param name="currentCityLocation"></param>
        /// <returns></returns>
        public bool IsValidCyclistObjectByLocationId(int cyclistObjectId, int currentCityLocation)
        {
            List<int> cyclistObjectIds = new List<int>();

            //
            // create a list of cyclist object ids in current city location
            //
            foreach (GameObject gameObject in _gameObjects)
            {
                if (gameObject.CityLocationId == currentCityLocation && gameObject is CyclistObject)
                {
                    cyclistObjectIds.Add(gameObject.Id);
                }

            }

            //
            // determine if the game object id is a valid id and return the result
            //
            if (cyclistObjectIds.Contains(cyclistObjectId))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// Get game object using the ID
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public GameObject GetGameObjectById(int Id)
        {
             GameObject gameObjectToReturn = null;

            //
            //go through the game object list and get the right one
            //
            foreach (GameObject gameObject in _gameObjects)
            {
                if (gameObject.Id == Id)
                {
                    gameObjectToReturn = gameObject; 
                }
            }
            //
            //Specified Id not found in City
            //throw exception
            //
            if (gameObjectToReturn == null)
            {
                string feedbackMessage = $"The City object ID {Id} does not exist in the City.";
                throw new ArgumentException(Id.ToString(), feedbackMessage);
            }
            return gameObjectToReturn; 
        }
        
        public List<GameObject> GetGameObjectByCityLocationId(int CityLocationId)
        {
            List<GameObject> gameObjects = new List<GameObject>();

            //
            //Show the objects in the current location
            // 
            foreach (GameObject gameObject in _gameObjects)
            {
                if (gameObject.CityLocationId == CityLocationId)
                {
                    gameObjects.Add(gameObject);
                }
            }
            return gameObjects; 
        }
        public List<CyclistObject> GetCyclistObjectsByCityLocationId(int cityLocationId)
        {
            List<CyclistObject> cyclistObjects = new List<CyclistObject>();

            //
            // run through the game object list and grab all that are in the current city location
            //
            foreach (GameObject gameObject in _gameObjects)
            {
                if (gameObject.CityLocationId == cityLocationId && gameObject is CyclistObject)
                {
                    cyclistObjects.Add(gameObject as CyclistObject);
                }
            }

            return cyclistObjects;
        }
        public bool IsValidNpcByLocationId(int npcId, int currentCityLocation)
        {
            List<int> npcIds = new List<int>();

            //
            //List NPCs in current location
            //
            foreach (Npc npc in _npcs)
            {
                if (npc.CityLocationId == currentCityLocation)
                {
                    npcIds.Add(npc.Id);
                }
            }
            //
            //check that the game object id is valid and return result
            //
            if (npcIds.Contains(npcId))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
            public Npc GetNpcById(int Id)
        {
            Npc npcToReturn = null;
            //
            //run through npc list and get correct one
            //
            foreach (Npc npc in _npcs)
            {
                if (npc.Id == Id)
                {
                    npcToReturn = npc; 
                  
                }
                //
                //if id not found in city
                //
                if (npcToReturn == null)
                {
                    string feedbackMessage = $"The NPC ID {Id} does not exist in Cherry Town.";
                   // throw new ArgumentException(Id.ToString(), feedbackMessage);
                }
            }
            return npcToReturn;
        }
        public List<Npc> GetNpcByCityLocationId(int cityLocationId)
        {
            List<Npc> npcs = new List<Npc>();
            //
            //check object list and grab all that are in the current location
            //
            foreach  (Npc npc in _npcs)
            {
                if (npc.CityLocationId == cityLocationId)
                {
                    npcs.Add(npc);
                }
            }
            return npcs; 

        }
        }
        #endregion

    }

